//#include <log/log.h>
#define ALOGV printf
#define ALOGI printf
#define ALOGE printf

